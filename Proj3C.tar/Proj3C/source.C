#include "image.h"
#include "source.h"

Image * source::GetOutput()
{
    return &image;
}

source::source()
{
};